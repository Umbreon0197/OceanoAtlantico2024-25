import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '5rem' }}>
      <h1>🌴 Bienvenido a Jungla Frontend 🌴</h1>
      <p>Frontend corriendo dentro de Docker con Nginx 🚀</p>
    </div>
  );
}

export default App;